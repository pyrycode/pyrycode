import collections
import hashlib
import json
import sys
from pathlib import Path

for name in sys.argv[1:]:
    path = Path(name)
    records = []
    starts = {}
    outputs = collections.defaultdict(list)
    packages = []
    for line in path.read_text().splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        test = event.get('Test')
        if test:
            if event['Action'] == 'run':
                starts[test] = event['Time']
            if event['Action'] == 'output':
                outputs[test].append(event['Output'])
            if event['Action'] in ('pass', 'fail', 'skip'):
                records.append({k: event.get(k) for k in ('Test', 'Action', 'Elapsed')})
        elif event['Action'] in ('pass', 'fail', 'skip'):
            packages.append(event)
    names = {r['Test'] for r in records}
    parents = set()
    for n in names:
        parts = n.split('/')
        parents.update('/'.join(parts[:i]) for i in range(1, len(parts)))
    parents &= names
    stats = lambda rows: dict(collections.Counter(r['Action'] for r in rows))
    result = dict(file=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  records=len(records), outcomes=stats(records),
                  parents=stats([r for r in records if r['Test'] in parents]),
                  leaves=stats([r for r in records if r['Test'] not in parents]),
                  packages=packages,
                  incomplete=sorted(set(starts)-names),
                  failures=[r for r in records if r['Action']=='fail'],
                  skips={r['Test']: ''.join(outputs[r['Test']]) for r in records if r['Action']=='skip'},
                  slowest=sorted(records, key=lambda r:r.get('Elapsed',0), reverse=True)[:15])
    target = path.with_suffix('.summary.json')
    target.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
