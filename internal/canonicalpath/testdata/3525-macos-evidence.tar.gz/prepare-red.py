import json
from pathlib import Path

repo = Path.cwd()
scratch = Path('/tmp/builder-3525')
source = (scratch / 'base-path.go').read_text()
source = source.replace('os.ReadDir(canonical)', 'recoveryReadDir(canonical)')
source += '''
var recoveryScanHook func(string, int)
func recoveryReadDir(path string) ([]os.DirEntry, error) {
    entries, err := os.ReadDir(path)
    if recoveryScanHook != nil { recoveryScanHook(path, len(entries)) }
    return entries, err
}
'''
(scratch / 'red-path.go').write_text(source)
(scratch / 'red-overlay.json').write_text(json.dumps({'Replace': {
    str(repo / 'internal/canonicalpath/path.go'): str(scratch / 'red-path.go'),
    str(repo / 'internal/canonicalpath/runtime_darwin_test.go'): '/tmp/builder-3504/recovery_fanout_test.go',
}}))
