import json
from pathlib import Path

repo = Path.cwd()
scratch = Path('/tmp/builder-3504')
source = (repo / 'internal/canonicalpath/path.go').read_text()
assert source.count('os.ReadDir(canonical)') == 1
source = source.replace('os.ReadDir(canonical)', 'recoveryReadDir(canonical)')
source += '''
var recoveryScanHook func(string, int)
func recoveryReadDir(path string) ([]os.DirEntry, error) {
    entries, err := os.ReadDir(path)
    if recoveryScanHook != nil { recoveryScanHook(path, len(entries)) }
    return entries, err
}
'''
(scratch / 'canonical-counted.go').write_text(source)
(scratch / 'fanout-overlay.json').write_text(json.dumps({'Replace': {
    str(repo / 'internal/canonicalpath/path.go'): str(scratch / 'canonical-counted.go'),
    str(repo / 'internal/canonicalpath/recovery_fanout_test.go'): str(scratch / 'recovery_fanout_test.go'),
}}))
