package canonicalpath

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestRecoveryCanonicalCaseFanout(t *testing.T) {
	root, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil { t.Fatal(err) }
	leaf := filepath.Join(root, "Workspace", "Child")
	if err := os.MkdirAll(leaf, 0o700); err != nil { t.Fatal(err) }
	const repeats = 16
	measure := func() (int, int, time.Duration) {
		calls, entries := 0, 0
		recoveryScanHook = func(path string, n int) {
			if path == root { calls++; entries += n }
		}
		defer func() { recoveryScanHook = nil }()
		start := time.Now()
		for i := 0; i < repeats; i++ {
			got, err := Resolve(leaf)
			if err != nil || got != leaf { t.Fatalf("Resolve = %q, %v", got, err) }
		}
		return calls, entries, time.Since(start)
	}
	calls, entries, elapsed := measure()
	t.Logf("small: resolutions=%d ancestor_scans=%d ancestor_entries=%d elapsed=%s", repeats, calls, entries, elapsed)
	for i := 0; i < 35000; i++ {
		if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("sibling-%05d", i)), nil, 0o600); err != nil { t.Fatal(err) }
	}
	calls, entries, elapsed = measure()
	t.Logf("wide: resolutions=%d ancestor_scans=%d ancestor_entries=%d elapsed=%s", repeats, calls, entries, elapsed)
	if calls > 1 { t.Fatalf("repeated full ancestor enumeration: %d scans and %d entries for %d resolutions", calls, entries, repeats) }
}
