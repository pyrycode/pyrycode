import json
from pathlib import Path

root = Path('/Users/juhanailmoniemi/Workspace/Projects/.pyrycode-worktrees/pyrycode/builder-3504')
target = root / 'cmd/pyry/daemon_thread_demand_test.go'
source = target.read_text()
start = source.index('func TestDaemonThreadDemandWireAfterIdle(')
end = source.index('\nfunc TestDaemonThreadDemandCancellation(', start)
test = source[start:end]
test = test.replace('\ts.start()\n', '\ts.start()\n', 1)
signal = '''	idleConsidered := make(chan struct{}, 1)
	s.quiet = func(conversations.ConversationID) bool {
		select {
		case idleConsidered <- struct{}{}:
		default:
		}
		return true
	}
'''
wire = '''	w, _ := testDaemonThreadQueryWire(t, s, func(cfg *relay.V2SessionConfig) {
		query := cfg.ThreadCatchUp
		cfg.ThreadCatchUp = func(ctx context.Context, p protocol.ThreadCatchUpPayload) (thread.QueryResult, error) {
			got, err := query(ctx, p)
			if err != nil {
				return got, err
			}
			// Force a coordinator publication/idle consideration before query completion.
			select {
			case <-idleConsidered:
			case <-ctx.Done():
				return thread.QueryResult{}, ctx.Err()
			}
			return got, nil
		}
	})
'''
test = test.replace('\tw, _ := testDaemonThreadQueryWire(t, s, nil)\n', signal + wire, 1)
test = test.replace('\tw.open("phone", false, protocol.CapabilityThread)\n', '\t<-idleConsidered // discard initial retirement notification\n\tw.open("phone", false, protocol.CapabilityThread)\n', 1)
for mode in ('old', 'fixed'):
    variant = test
    if mode == 'old':
        variant = variant.replace(wire, '', 1)
        variant = variant.replace('\t<-idleConsidered', wire + '\t<-idleConsidered', 1)
    overlay_source = Path('/tmp/builder-3504') / f'idle-{mode}-control.go'
    overlay_source.write_text(source[:start] + variant + source[end:])
    overlay = Path('/tmp/builder-3504') / f'idle-{mode}-overlay.json'
    overlay.write_text(json.dumps({'Replace': {str(target): str(overlay_source)}}))
