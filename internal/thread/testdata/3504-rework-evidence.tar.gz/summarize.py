"""Count raw Go JSON events without treating skips or cache hits as passes."""
import collections
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
summary = {}
for path in sorted([*root.glob("*.jsonl"), *root.glob("*.log")]):
    counts = collections.Counter()
    packages, skips, failures = [], [], []
    for line in path.read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(event, dict):
            continue
        action = event.get("Action")
        if event.get("Test"):
            if action in ("run", "pass", "fail", "skip"):
                counts[action] += 1
            if action == "skip":
                skips.append([event["Package"], event["Test"]])
            if action == "fail":
                failures.append([event["Package"], event["Test"]])
        elif action in ("pass", "fail", "skip"):
            packages.append({key: event[key] for key in ("Package", "Action", "Elapsed") if key in event})
    summary[path.name] = {
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "counts": dict(counts),
        "packages": packages,
        "skips": skips,
        "failures": failures,
    }
print(json.dumps(summary, indent=2))
